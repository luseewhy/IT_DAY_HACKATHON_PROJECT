# AI-POWERED-LEARNING-APP_-Pixel-pirates
1. Run the program in "Project" Directory, "AI-POWERED-LEARNING-APP_-Pixel Pirates".


2.For going back in this application The button "BACK" is provided and for Certain Other file you can use "q"-key.



3. 
![WhatsApp Image 2023-03-21 at 10 23 49](https://user-images.githubusercontent.com/90235816/226522232-274c84a4-f34c-49aa-ad3f-6c70a536f395.jpg)

Further, Sign in screen there are multi purposed sub apps that helps you Perform different procedures like Yoga Postures pose, Sign detection.

4. For Example: 
![WhatsApp Image 2023-03-21 at 10 23 59](https://user-images.githubusercontent.com/90235816/226522264-87096afd-0db3-4195-99af-ef8ffb21e869.jpg)

![WhatsApp Image 2023-03-21 at 10 24 33](https://user-images.githubusercontent.com/90235816/226522300-3dc62ba3-aa04-4c1a-be7d-8ec2fd53ff69.jpg)
### Yoga pose detection.
